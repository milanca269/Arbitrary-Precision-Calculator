#ifndef APC_H
#define APC_H
#define SUCCESS 0
#define FAILURE -1
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct node
{
	int data;
	struct node *prev;
	struct node *next;
}Dlist;

int validate_operand(char *);
int validate_operator(char *);
int compare_lists(Dlist *head1,Dlist *head2);
int dl_delete_list(Dlist **head, Dlist **tail);
int dl_insert_last(Dlist **, Dlist **, int);
int dl_insert_first(Dlist **, Dlist **, int );
void print_list(Dlist *head);
int addition(Dlist **,Dlist **,Dlist **,Dlist **);
int substraction(Dlist **,Dlist**,Dlist**,Dlist** );
int mutliplication(Dlist **,Dlist **,Dlist **,Dlist **);
int division(Dlist **,Dlist **,Dlist **,Dlist **,Dlist **,Dlist **);
void print_number(Dlist *head);

#endif
