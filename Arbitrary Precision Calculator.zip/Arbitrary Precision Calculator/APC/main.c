#include "APC.h"

int main(int argc, char *argv[])
{
    if (argc < 4)
    {
        printf("Invalid input\n");
        return 0;
    }

    // Validate operands
    if (validate_operand(argv[1]) || validate_operand(argv[3]))
    {
        printf("Enter only digits for operand\n");
        return 0;
    }

    // Validate operator
    if (validate_operator(argv[2]))
    {
        printf("Invalid operator\n");
        return 0;
    }

    int sign1 = 1, sign2 = 1;

    if (argv[1][0] == '-')
        sign1 = -1;

    if (argv[3][0] == '-')
        sign2 = -1;

    char operator = argv[2][0];

    // Creating lists
    Dlist *head1 = NULL, *tail1 = NULL;
    Dlist *head2 = NULL, *tail2 = NULL;
    Dlist *head_r = NULL, *tail_r = NULL;

    int start1 = (argv[1][0] == '+' || argv[1][0] == '-') ? 1 : 0;
    int start2 = (argv[3][0] == '+' || argv[3][0] == '-') ? 1 : 0;

    // Insert operand1
    for (int i = start1; argv[1][i] != '\0'; i++)
    {
        if (dl_insert_last(&head1, &tail1, argv[1][i] - '0') == FAILURE)
        {
            printf("Insertion Failure\n");
            return 0;
        }
    }

    // Insert operand2
    for (int i = start2; argv[3][i] != '\0'; i++)
    {
        if (dl_insert_last(&head2, &tail2, argv[3][i] - '0') == FAILURE)
        {
            printf("Insertion Failure\n");
            return 0;
        }
    }

    int result_sign = 1;

    switch (operator)
    {
        case '+':
        {
            if (sign1 == sign2)
            {
                if (addition(&tail1, &tail2, &head_r, &tail_r) == FAILURE)
                {
                    printf("Addition failed\n");
                    return 0;
                }
                result_sign = sign1;
            }
            else
            {
                int cmp = compare_lists(head1, head2);

                if (cmp == 0)
                {
                    dl_insert_first(&head_r, &tail_r, 0);
                    result_sign = 1;
                }
                else if (cmp > 0)
                {
                    if (substraction(&tail1, &tail2, &head_r, &tail_r) == FAILURE)
                    {
                        printf("Subtraction failed\n");
                        return 0;
                    }
                    result_sign = sign1;
                }
                else
                {
                    if (substraction(&tail2, &tail1, &head_r, &tail_r) == FAILURE)
                    {
                        printf("Subtraction failed\n");
                        return 0;
                    }
                    result_sign = sign2;
                }
            }
            break;
        }

        case '-':
        {
            if (sign1 != sign2)
            {
                if (addition(&tail1, &tail2, &head_r, &tail_r) == FAILURE)
                {
                    printf("Addition failed\n");
                    return 0;
                }
                result_sign = sign1;
            }
            else
            {
                int cmp = compare_lists(head1, head2);

                if (cmp == 0)
                {
                    dl_insert_first(&head_r, &tail_r, 0);
                    result_sign = 1;
                }
                else if (cmp > 0)
                {
                    if (substraction(&tail1, &tail2, &head_r, &tail_r) == FAILURE)
                    {
                        printf("Subtraction failed\n");
                        return 0;
                    }
                    result_sign = sign1;
                }
                else
                {
                    if (substraction(&tail2, &tail1, &head_r, &tail_r) == FAILURE)
                    {
                        printf("Subtraction failed\n");
                        return 0;
                    }
                    result_sign = -sign1;
                }
            }
            break;
        }

        case 'x':
        {
            if (mutliplication(&tail1, &tail2, &head_r, &tail_r) == FAILURE)
            {
                printf("Multiplication failed\n");
                return 0;
            }
            result_sign = sign1 * sign2;
            break;
        }

        case '/':
        {
            if (head2 == NULL || (head2->data == 0 && head2->next == NULL))
            {
                printf("Error: Division by zero\n");
                return 0;
            }

            if (division(&head1, &tail1, &head2, &tail2, &head_r, &tail_r) == FAILURE)
            {
                printf("Division failed\n");
                return 0;
            }

            result_sign = sign1 * sign2;
            break;
        }

        default:
            printf("Invalid operator\n");
            return 0;
    }

    // ✅ Single Clean Output Section
    printf("\n");
    printf("================================\n");
    printf("        APC CALCULATOR\n");
    printf("================================\n");

    printf("expression : %s%s%s\n", argv[1], argv[2], argv[3]);

    printf("result : ");

    if (result_sign == -1)
        printf("-");

    print_number(head_r);
    printf("\n\n");

    return 0;
}

