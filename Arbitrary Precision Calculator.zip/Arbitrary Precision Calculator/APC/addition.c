#include"APC.h"
// Function to add two large numbers stored in doubly linked lists.
int addition(Dlist **tail_1,Dlist **tail_2,Dlist **head_r,Dlist **tail_r){
    Dlist *temp1=*tail_1;// Pointer to traverse first number from last digit
    Dlist *temp2=*tail_2;// Pointer to traverse second number from last digit
    int sum,carry=0,digit;

    while(temp1!=NULL   || temp2!=NULL  || carry!=0){// Continue until both linked lists and carry are fully processed
      // If a list has ended, take digit as 0  
      int val1 = (temp1 != NULL) ? temp1->data : 0;
        int val2 = (temp2 != NULL) ? temp2->data : 0;


        
      sum=val1+val2+carry;// Calculate sum with carry

      if(sum>9){// If sum is more than 9, set carry for next round
        carry=1;
        digit=sum-10;// Only the unit digit is stored
      }
      else{
        carry=0;
        digit=sum;// Store sum directly if < 10
      }
      if ( dl_insert_first(head_r,tail_r,digit)== FAILURE) //pass by reference
				{
					printf("INFO : Insertion Failure\n");
                    return FAILURE;
				}
// Move to previous digits in both lists
            if (temp1 != NULL)
            temp1 = temp1->prev;
            if (temp2 != NULL)
            temp2 = temp2->prev;
    }
        return  SUCCESS;
}
