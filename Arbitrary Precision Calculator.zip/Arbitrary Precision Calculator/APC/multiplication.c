#include "APC.h"
// Function to multiply two large numbers represented using Doubly Linked Lists
int mutliplication(Dlist **tail_1,Dlist **tail_2,
                   Dlist **head_r, Dlist **tail_r)
{
     Dlist *head_prev = NULL, *tail_prev = NULL;
    Dlist *t1 = *tail_1;
    int shift = 0;  // how many zeros to append (place value)

    while (t1)
    {
        int carry = 0;
        Dlist *head_temp = NULL, *tail_temp = NULL;// Stores previous result for addition
        
        Dlist *t2 = *tail_2;

        // add shift zeros at end (since insert to last)
        for (int i = 0; i < shift; i++)
        {
            if (dl_insert_first(&head_temp, &tail_temp, 0) == FAILURE)
                return FAILURE;
        }

        // multiply current digit of num1 with all digits of num2
        while (t2)
        {
            int prod = t1->data * t2->data + carry;
            carry = prod / 10;
            int digit = prod % 10;

            // insert at front since we are building reverse
            if (dl_insert_first(&head_temp, &tail_temp, digit) == FAILURE)
                return FAILURE;

            t2 = t2->prev;
        }

        if (carry)
        {
            if (dl_insert_first(&head_temp, &tail_temp, carry) == FAILURE)
                return FAILURE;
        }

        // // add this partial product into result
        // if (addition(&head_temp, &tail_temp, head_r, tail_r) == FAILURE)
        //     return FAILURE;

        if(*head_r==NULL){
            *head_r=head_temp;
            *tail_r=tail_temp;
        }
        else{
           head_prev = *head_r;
            tail_prev = *tail_r;

            *head_r = NULL;
            *tail_r = NULL;
            if (addition(&tail_temp, &tail_prev, head_r, tail_r) == FAILURE)
            return FAILURE;
           dl_delete_list(&head_prev ,&tail_prev );
        }
        shift++;       // increase decimal place
        t1 = t1->prev; // next digit in num1
    }

    return SUCCESS;
}
