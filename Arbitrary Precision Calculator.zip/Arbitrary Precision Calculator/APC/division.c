#include "APC.h"

// Function to perform division using long division logic
int division(Dlist **head1, Dlist **tail1,
             Dlist **head2, Dlist **tail2,
             Dlist **head_r, Dlist **tail_r)
{
    // Remove leading zeros from dividend and divisor
    while (*head1 && (*head1)->data == 0 && (*head1)->next != NULL)
        *head1 = (*head1)->next;

    while (*head2 && (*head2)->data == 0 && (*head2)->next != NULL)
        *head2 = (*head2)->next;

    // If dividend < divisor, quotient = 0
    if (compare_lists(*head1, *head2) < 0)
    {
        dl_insert_last(head_r, tail_r, 0);
        return SUCCESS;
    }

    // If equal, quotient = 1
    if (compare_lists(*head1, *head2) == 0)
    {
        dl_insert_last(head_r, tail_r, 1);
        return SUCCESS;
    }

    Dlist *partial_head = NULL, *partial_tail = NULL; // Temporary partial dividend
    Dlist *d = *head1; // Traversing original dividend

    while (d)
    {
        // Bring down next digit from dividend
        if (dl_insert_last(&partial_head, &partial_tail, d->data) == FAILURE)
            return FAILURE;

        // Trim leading zeros in partial value
        while (partial_head && partial_head->data == 0 && partial_head->next != NULL)
            partial_head = partial_head->next;

        // Find quotient digit by trying 9→0
        int q = 0;
        for (int digit = 9; digit >= 0; digit--)
        {
            Dlist *mul_head = NULL, *mul_tail = NULL;
            Dlist *temp_head = NULL, *temp_tail = NULL;

            // Create digit list
            if (dl_insert_last(&temp_head, &temp_tail, digit) == FAILURE)
                return FAILURE;

            // Multiply divisor × digit
            if (mutliplication(tail2, &temp_tail, &mul_head, &mul_tail) == FAILURE)
                return FAILURE;

            // Compare product with partial
            if (compare_lists(partial_head, mul_head) >= 0)
            {
                q = digit;  // digit fits
                // Compute new partial = partial - product
                dl_delete_list(&temp_head, &temp_tail);
                Dlist *new_partial_head = NULL, *new_partial_tail = NULL;

                if (substraction(&partial_tail, &mul_tail, &new_partial_head, &new_partial_tail) == FAILURE)
                    return FAILURE;

                dl_delete_list(&partial_head, &partial_tail);
                partial_head = new_partial_head;
                partial_tail = new_partial_tail;

                dl_delete_list(&mul_head, &mul_tail);
                break;
            }

            dl_delete_list(&temp_head, &temp_tail);
            dl_delete_list(&mul_head, &mul_tail);
        }

        // Append quotient digit to final result
        if (dl_insert_last(head_r, tail_r, q) == FAILURE)
            return FAILURE;

        d = d->next;
    }

    return SUCCESS;
}
