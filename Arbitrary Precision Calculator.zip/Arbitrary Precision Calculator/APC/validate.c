#include"APC.h"
int validate_operand(char *digit){
    int i=0;
    if(digit[0]=='+' || digit[0]=='-'){
        i=1;
    }
    int length1=strlen(digit);
for(i;i<length1;i++){
    if(!(digit[i]>='0'  && digit[i]<='9')){
   
      return 1;
    }
}

return 0;
}

int validate_operator(char *operator)
{
    if (operator[1] != '\0')   // only one character allowed
        return 1;

    if (operator[0] == '+' || operator[0] == '-' ||
        operator[0] == 'x' || operator[0] == '/')
    {
        return 0;  // valid
    }
    return 1;      // invalid
}


int dl_insert_first(Dlist **head, Dlist **tail, int data)
{
    //create, validate, update
        Dlist *new = malloc(sizeof(Dlist));
        if (new == NULL)
            return FAILURE;
        new->data = data;
        new->next = *head;
        new->prev = NULL;
        
        // Check for list empty
        if (*head == NULL)
        {
            *head = new;
            *tail = new;
            return SUCCESS;
        }
        
        (*head)->prev = new;
        *head = new;
        return SUCCESS;
        
        
}
int dl_insert_last(Dlist **head, Dlist **tail, int data)
{
Dlist *new =malloc(sizeof(Dlist));
if(new==NULL){
    return FAILURE;
    
}
new->data=data;
new->next=NULL;
new->prev=*tail;

if(*head==NULL){
    *head=new;
    *tail=new;
    return SUCCESS;
}
(*tail)->next=new;
*tail=new;
return SUCCESS;
}

void print_list(Dlist *head)
{
	/* Cheking the list is empty or not */
	if (head == NULL)
	{
		printf("INFO : List is empty\n");
	}
	else
	{
	    printf("Head -> ");
	    while (head)		
	    {
		    /* Printing the list */
		    printf("%d <-", head -> data);

		    /* Travering in forward direction */
		    head = head -> next;
		    if (head)
		        printf("> ");
	    }
    	printf(" Tail\n");
    }
}
void print_number(Dlist *head)
{
    Dlist *temp = head;

    if (head == NULL)
    {
        printf("0\n");
        return;
    }

   

    while (temp != NULL)
    {
      
        printf("%d", temp->data);  // print digits together
        temp = temp->next;
    }
    printf("\n");
}


int dl_delete_list(Dlist **head, Dlist **tail)
{
if(*head==NULL){
    return FAILURE;
}
Dlist*temp=*head;
Dlist*nextnode;

while(temp!=NULL){
   nextnode = temp->next; 
        free(temp);           
        temp = nextnode; 
}
*head=NULL;
*tail=NULL;
return SUCCESS;
}
int compare_lists(Dlist *head1,Dlist *head2){
    int len1=0,len2=0;
    Dlist *t1=head1,*t2=head2;
    while(t1){
        len1++;t1=t1->next;
    }
    while(t2){
        len2++;t2=t2->next;
    }
    if(len1>len2){
        return 1;
    }
    if(len2>len1){
        return -1;
    }
    t1=head1;
    t2=head2;
    while(t1&&t2){
        if(t1->data>t2->data)return 1;
        if(t1->data<t2->data)return -1;
        t1=t1->next;
        t2=t2->next;
    }
    return 0;
}
