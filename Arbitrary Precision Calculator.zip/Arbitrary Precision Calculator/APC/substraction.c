#include"APC.h"
// Function to subtract two large numbers stored in doubly linked lists
int substraction(Dlist **tail_1,Dlist **tail_2,Dlist **head_r,Dlist **tail_r){
    
     Dlist *temp1=*tail_1;// Traverse digits of number1 
     Dlist *temp2=*tail_2;// Traverse digits of number2 
     int borrow=0,digit,differnce,is_borrow;
 // Continue until both lists are traversed completely
     while(temp1!=NULL   || temp2!=NULL  ){
       int val1=(temp1 != NULL) ? temp1->data : 0;
       // If node is NULL, consider digit as 0
       int val2=(temp2 != NULL) ? temp2->data : 0;
       val1=val1-borrow;// Apply previous borrow to current digit
       borrow=0;
       if(val1<val2){// If subtraction requires borrowing (val1 < val2)
        borrow=1;
        val1=val1+10;
       }
      
       differnce=val1-val2;// Final digit difference
      
        if ( dl_insert_first(head_r,tail_r,differnce)== FAILURE) //pass by reference
				{
					printf("INFO : Insertion Failure\n");
                    return FAILURE;
				}

               // Move to previous digits
              if (temp1 != NULL)
              temp1 = temp1->prev;
              if (temp2 != NULL)
              temp2 = temp2->prev;
     }
     return SUCCESS;


}
